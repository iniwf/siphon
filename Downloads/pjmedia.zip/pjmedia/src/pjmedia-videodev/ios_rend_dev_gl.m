/* $Id: ios_dev.m 3979 2012-03-20 08:55:33Z ming $ */
/*
 * Copyright (C) 2012 Samuel Vinson (samuelv0304@gmail.com)
 * Copyright (C) 2008-2011 Teluu Inc. (http://www.teluu.com)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
#include <pjmedia-videodev/videodev_imp.h>
#include <pj/assert.h>
#include <pj/log.h>
#include <pj/os.h>

#if defined(PJMEDIA_VIDEO_DEV_HAS_IOS) && PJMEDIA_VIDEO_DEV_HAS_IOS != 0 && \
    defined(PJMEDIA_HAS_VIDEO) && (PJMEDIA_HAS_VIDEO != 0)

#import <Availability.h>
//#ifdef __IPHONE_4_0

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

#define ORIENTATION 0

//#ifdef __IPHONE_5_0 || __IPHONE_6_0

#import <GLKit/GLKit.h>
#import <pjmedia-videodev/ShaderUtilities.h>
//#endif

#if 1
#   define TRACE_(x)    PJ_LOG(1,x)
#else
#   define TRACE_(x)
#endif
#define THIS_FILE		"ios_rend_dev.m"
#define DEFAULT_CLOCK_RATE	90000
//#define DEFAULT_WIDTH		480
//#define DEFAULT_HEIGHT	360
#define DEFAULT_WIDTH		352
#define DEFAULT_HEIGHT		288
//#define DEFAULT_WIDTH		640
//#define DEFAULT_HEIGHT		480
#define DEFAULT_FPS		15

// Vertex/Fragment shader source
static const GLchar yuv2rgb_vertex_shader[] = " \
    attribute vec4 position; \
    attribute mediump vec4 textureCoordinate; \
    varying mediump vec2 coordinate; \
    \
    void main() \
    { \
      gl_Position = position; \
      coordinate = textureCoordinate.xy; \
    } \
";

static const GLchar yuv2rgb_fragment_shader[] = " \
    uniform sampler2D SamplerY; \
    uniform sampler2D SamplerU; \
    uniform sampler2D SamplerV; \
    \
    varying highp vec2 coordinate; \
    \
    void main() \
    { \
      mediump vec3 yuv; \
      lowp vec3 rgb; \
      \
      yuv.x = texture2D(SamplerY, coordinate).r; \
      yuv.y = texture2D(SamplerU, coordinate).r - 0.5; \
      yuv.z = texture2D(SamplerV, coordinate).r - 0.5; \
      \
      rgb = mat3(1,             1,      1, \
                 0,       -.18732, 1.8556, \
                 1.57481, -.46813,      0) * yuv; \
      \
      gl_FragColor = vec4(rgb, 1); \
    } \
";

// Attribute index.
enum {
  ATTRIB_VERTEX,
  ATTRIB_TEXTUREPOSITON,
  NUM_ATTRIBUTES
};

// Uniform index.
enum
{
  UNIFORM_Y,
  UNIFORM_U,
  UNIFORM_V,
  NUM_UNIFORMS
};

GLint uniformLocations[NUM_UNIFORMS];

#if ORIENTATION
typedef struct ios_orient
{
  pjmedia_orient pjmedia_orientation;
  AVCaptureVideoOrientation av_orientation;
  UIImageOrientation ui_orientation;
} ios_orient;

static ios_orient ios_orients[] =
{
  {PJMEDIA_ORIENT_NATURAL, AVCaptureVideoOrientationPortrait,
    UIImageOrientationUp},
  {PJMEDIA_ORIENT_ROTATE_180DEG, AVCaptureVideoOrientationPortraitUpsideDown,
    UIImageOrientationDown},
  {PJMEDIA_ORIENT_ROTATE_90DEG,  AVCaptureVideoOrientationLandscapeRight,
    UIImageOrientationRight},
  {PJMEDIA_ORIENT_ROTATE_270DEG, AVCaptureVideoOrientationLandscapeLeft,
    UIImageOrientationLeft},
} ;
#endif /* ORIENTATION */


typedef struct ios_fmt_info
{
    pjmedia_format_id   pjmedia_format;
    UInt32		ios_format;
} ios_fmt_info;

static ios_fmt_info ios_fmts[] =
{
    {PJMEDIA_FORMAT_I420 , kCVPixelFormatType_420YpCbCr8BiPlanarVideoRange},
//	{PJMEDIA_FORMAT_NV12, kCVPixelFormatType_420YpCbCr8BiPlanarVideoRange},
//	{PJMEDIA_FORMAT_I420, kCVPixelFormatType_420YpCbCr8BiPlanarFullRange},
};

/* ios device info */
struct ios_dev_info
{
    pjmedia_vid_dev_info	 info;
    char			         dev_id[192];
};

/* ios factory */
struct ios_factory
{
    pjmedia_vid_dev_factory	 base;
    pj_pool_t			*pool;
    pj_pool_t			*dev_pool;
    pj_pool_factory		*pf;

    unsigned			 dev_count;
    struct ios_dev_info		*dev_info;
};

struct ios_stream;
typedef pj_status_t (*func_ptr)(struct ios_stream *strm);


@interface FuncDelegate: NSObject
{
@public
    struct ios_stream *strm;
    func_ptr           func;
    pj_status_t        status;
}

- (void)run_func;
@end

@implementation FuncDelegate

- (void)run_func
{
	status = (*func)(strm);
}

@end

static void run_func_on_main_thread(struct ios_stream *strm, func_ptr func,
                                    pj_status_t *retval)
{
  NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
  FuncDelegate *delg = [[FuncDelegate alloc] init];
  
  delg->strm = strm;
  delg->func = func;
  //delg->status = PJ_SUCCESS;
  [delg performSelectorOnMainThread:@selector(run_func)
                         withObject:nil waitUntilDone:YES];
  
  // FIXME useful ?
  CFRunLoopRunInMode(kCFRunLoopDefaultMode, 0, false);
  
  *retval = delg->status;
  
  [delg release];
  [pool release];
}

@interface GLView : UIView

@end

@implementation GLView

+ (Class) layerClass
{
  return [CAEAGLLayer class];
}

@end

/* Video stream. */
struct ios_stream
{
    pjmedia_vid_dev_stream  base;	    /**< Base stream       */
    pjmedia_vid_dev_param   param;	    /**< Settings	       */
    pj_pool_t		   *pool;           /**< Memory pool       */

    pjmedia_vid_dev_cb	    vid_cb;		/**< Stream callback   */
    void		   *user_data;          /**< Application data  */

    struct ios_factory     *qf;
    const pjmedia_frame *frame;

    pj_bool_t               is_running;
  
    //void		    *buf;
    unsigned         frame_size;
    pjmedia_rect_size       size;
    pj_uint8_t              bpp;
  
    EAGLContext *glContext;
    GLuint frameBufferHandle;
    GLuint colorBufferHandle;

    GLView      *glView;
    GLuint       glProgram;

    GLuint lumaTexture;
    GLuint chromaUTexture;
    GLuint chromaVTexture;
  
    int renderBufferWidth;
    int renderBufferHeight;
};


/* Prototypes */
static pj_status_t ios_factory_init(pjmedia_vid_dev_factory *f);
static pj_status_t ios_factory_destroy(pjmedia_vid_dev_factory *f);
static pj_status_t ios_factory_refresh(pjmedia_vid_dev_factory *f);
static unsigned    ios_factory_get_dev_count(pjmedia_vid_dev_factory *f);
static pj_status_t ios_factory_get_dev_info(pjmedia_vid_dev_factory *f,
					   unsigned index,
					   pjmedia_vid_dev_info *info);
static pj_status_t ios_factory_default_param(pj_pool_t *pool,
					    pjmedia_vid_dev_factory *f,
					    unsigned index,
					    pjmedia_vid_dev_param *param);
static pj_status_t ios_factory_create_stream(
					pjmedia_vid_dev_factory *f,
					pjmedia_vid_dev_param *param,
					const pjmedia_vid_dev_cb *cb,
					void *user_data,
					pjmedia_vid_dev_stream **p_vid_strm);

static pj_status_t ios_stream_get_param(pjmedia_vid_dev_stream *strm,
				       pjmedia_vid_dev_param *param);
static pj_status_t ios_stream_get_cap(pjmedia_vid_dev_stream *strm,
				     pjmedia_vid_dev_cap cap,
				     void *value);
static pj_status_t ios_stream_set_cap(pjmedia_vid_dev_stream *strm,
				     pjmedia_vid_dev_cap cap,
				     const void *value);
static pj_status_t ios_stream_start(pjmedia_vid_dev_stream *strm);
static pj_status_t ios_stream_put_frame(pjmedia_vid_dev_stream *strm,
					const pjmedia_frame *frame);
static pj_status_t ios_stream_stop(pjmedia_vid_dev_stream *strm);
static pj_status_t ios_stream_destroy(pjmedia_vid_dev_stream *strm);

/* Operations */
static pjmedia_vid_dev_factory_op factory_op =
{
    &ios_factory_init,
    &ios_factory_destroy,
    &ios_factory_get_dev_count,
    &ios_factory_get_dev_info,
    &ios_factory_default_param,
    &ios_factory_create_stream,
    &ios_factory_refresh
};

static pjmedia_vid_dev_stream_op stream_op =
{
    &ios_stream_get_param,
    &ios_stream_get_cap,
    &ios_stream_set_cap,
    &ios_stream_start,
    NULL,
    &ios_stream_put_frame,
    &ios_stream_stop,
    &ios_stream_destroy
};


/****************************************************************************
 * Factory operations
 */
/*
 * Init ios_ video driver.
 */
pjmedia_vid_dev_factory* pjmedia_ios_rend_factory(pj_pool_factory *pf)
{
    struct ios_factory *f;
    pj_pool_t *pool;

    pool = pj_pool_create(pf, "ios video renderer", 512, 512, NULL);
    f = PJ_POOL_ZALLOC_T(pool, struct ios_factory);
    f->pf = pf;
    f->pool = pool;
    f->base.op = &factory_op;

    return &f->base;
}


/* API: init factory */
static pj_status_t ios_factory_init(pjmedia_vid_dev_factory *f)
{
    return ios_factory_refresh(f);
}

/* API: destroy factory */
static pj_status_t ios_factory_destroy(pjmedia_vid_dev_factory *f)
{
    struct ios_factory *qf = (struct ios_factory*)f;
    pj_pool_t *pool = qf->pool;

    if (qf->dev_pool)
        pj_pool_release(qf->dev_pool);
    qf->pool = NULL;
    if (pool)
        pj_pool_release(pool);

    return PJ_SUCCESS;
}

/* API: refresh the list of devices */
static pj_status_t ios_factory_refresh(pjmedia_vid_dev_factory *f)
{
    struct ios_factory *qf = (struct ios_factory*)f;
    struct ios_dev_info *qdi;
    pjmedia_format *fmt;
    unsigned dev_count = 1;

    if (qf->dev_pool) {
        pj_pool_release(qf->dev_pool);
        qf->dev_pool = NULL;
    }

    /* Initialize input and output devices here */
    qf->dev_count = 0;
    qf->dev_pool = pj_pool_create(qf->pf, "ios video", 500, 500, NULL);
    
    qf->dev_info = (struct ios_dev_info*)
    pj_pool_calloc(qf->dev_pool, dev_count,
                   sizeof(struct ios_dev_info));
  
    qdi = &qf->dev_info[qf->dev_count++];
    pj_bzero(qdi, sizeof(*qdi));

    strcpy(qdi->info.name, "iOS GLView");
    strcpy(qdi->info.driver, "iOS GL");

    qdi->info.dir = PJMEDIA_DIR_RENDER;
    qdi->info.has_callback = PJ_FALSE;
    qdi->info.caps = PJMEDIA_VID_DEV_CAP_OUTPUT_WINDOW | PJMEDIA_VID_DEV_CAP_OUTPUT_POSITION |
        PJMEDIA_VID_DEV_CAP_OUTPUT_RESIZE | PJMEDIA_VID_DEV_CAP_OUTPUT_HIDE |
        PJMEDIA_VID_DEV_CAP_FORMAT;
    fmt = &qdi->info.fmt[qdi->info.fmt_cnt++];
    pjmedia_format_init_video(fmt,
                              ios_fmts[0].pjmedia_format,
                              DEFAULT_WIDTH,
                              DEFAULT_HEIGHT,
                              DEFAULT_FPS, 1);
    
    PJ_LOG(4, (THIS_FILE, "iOS video has %d devices",
	       qf->dev_count));
    
    return PJ_SUCCESS;
}

/* API: get number of devices */
static unsigned ios_factory_get_dev_count(pjmedia_vid_dev_factory *f)
{
    struct ios_factory *qf = (struct ios_factory*)f;
    return qf->dev_count;
}

/* API: get device info */
static pj_status_t ios_factory_get_dev_info(pjmedia_vid_dev_factory *f,
					    unsigned index,
					    pjmedia_vid_dev_info *info)
{
    struct ios_factory *qf = (struct ios_factory*)f;

    PJ_ASSERT_RETURN(index < qf->dev_count, PJMEDIA_EVID_INVDEV);

    pj_memcpy(info, &qf->dev_info[index].info, sizeof(*info));

    return PJ_SUCCESS;
}

/* API: create default device parameter */
static pj_status_t ios_factory_default_param(pj_pool_t *pool,
					     pjmedia_vid_dev_factory *f,
					     unsigned index,
					     pjmedia_vid_dev_param *param)
{
    struct ios_factory *qf = (struct ios_factory*)f;
    struct ios_dev_info *di = &qf->dev_info[index];

    PJ_ASSERT_RETURN(index < qf->dev_count, PJMEDIA_EVID_INVDEV);

    PJ_UNUSED_ARG(pool);

    pj_bzero(param, sizeof(*param));
    param->dir = PJMEDIA_DIR_RENDER;
    param->rend_id = index;
    param->cap_id = PJMEDIA_VID_INVALID_DEV;
    param->flags = PJMEDIA_VID_DEV_CAP_FORMAT;
    param->fmt.type = PJMEDIA_TYPE_VIDEO;
    param->clock_rate = DEFAULT_CLOCK_RATE;
    pj_memcpy(&param->fmt, &di->info.fmt[0], sizeof(param->fmt));

    return PJ_SUCCESS;
}

static ios_fmt_info* get_ios_format_info(pj_uint32_t /*pjmedia_format_id*/ id)
{
    unsigned i;
    
    for (i = 0; i < PJ_ARRAY_SIZE(ios_fmts); i++) {
        if (ios_fmts[i].pjmedia_format == (pjmedia_format_id)id)
            return &ios_fmts[i];
    }

    return NULL;
}

static pj_status_t initialize_gl_buffers(struct ios_stream *strm)
{
  pj_status_t success = PJ_SUCCESS;
	
  TRACE_((THIS_FILE, "initialize_gl_buffers"));
  
	glDisable(GL_DEPTH_TEST);
  
  glGenFramebuffers(1, &strm->frameBufferHandle);
  glBindFramebuffer(GL_FRAMEBUFFER, strm->frameBufferHandle);
  
  glGenRenderbuffers(1, &strm->colorBufferHandle);
  glBindRenderbuffer(GL_RENDERBUFFER, strm->colorBufferHandle);
  
  [strm->glContext renderbufferStorage:GL_RENDERBUFFER fromDrawable:(CAEAGLLayer *)[strm->glView layer]];
  
	glGetRenderbufferParameteriv(GL_RENDERBUFFER, GL_RENDERBUFFER_WIDTH, &strm->renderBufferWidth);
  glGetRenderbufferParameteriv(GL_RENDERBUFFER, GL_RENDERBUFFER_HEIGHT, &strm->renderBufferHeight);
  
  glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_RENDERBUFFER, strm->colorBufferHandle);
	if(glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE) {
    PJ_LOG(1, (THIS_FILE, "Failure with framebuffer generation"));
		success = PJMEDIA_EVID_SYSERR;
	}
  
  // attributes
  GLint attribLocation[NUM_ATTRIBUTES] = {
    ATTRIB_VERTEX, ATTRIB_TEXTUREPOSITON
  };
  const GLchar *attribName[NUM_ATTRIBUTES] = {
    "position", "textureCoordinate"
  };
  
  const GLchar *uniformNames[NUM_UNIFORMS] = {"SamplerY","SamplerU", "SamplerV"};
  
  glueCreateProgram(yuv2rgb_vertex_shader,
                    yuv2rgb_fragment_shader,
                    NUM_ATTRIBUTES, (const GLchar **)&attribName[0], attribLocation,
                    NUM_UNIFORMS, uniformNames, uniformLocations,
                    &strm->glProgram);
  
  if (!strm->glProgram)
    success = PJMEDIA_EVID_SYSERR;
  else
  {
    // Use shader program.
    glUseProgram(strm->glProgram);
    
    glUniform1i(uniformLocations[UNIFORM_Y], 0);
    glUniform1i(uniformLocations[UNIFORM_U], 1);
    glUniform1i(uniformLocations[UNIFORM_V], 2);
  }
  
  // FIXME use the correct size
  //buffer = (unsigned char *)malloc(3*1280*720/2);
  strm->frame_size = (strm->size.h * strm->size.w * strm->bpp) / 8;
  //strm->buf = pj_pool_zalloc(strm->pool, strm->frame_size);
  
  return success;
}

static void uninitialize_gl_buffers(struct ios_stream *strm)
{
  TRACE_((THIS_FILE, "uninitialize_gl_buffers"));
  glDeleteFramebuffers(1, &strm->frameBufferHandle);
	glDeleteRenderbuffers(1, &strm->colorBufferHandle);
}

static void initialize_gl_textures(struct ios_stream *strm)
{
  TRACE_((THIS_FILE, "initialize_gl_textures"));
  glGenTextures(1, &strm->lumaTexture);
  glGenTextures(1, &strm->chromaUTexture);
  glGenTextures(1, &strm->chromaVTexture);
}

static void uninitialize_gl_textures(struct ios_stream *strm)
{
  TRACE_((THIS_FILE, "uninitialize_gl_textures"));
  if (strm->lumaTexture) {
    glDeleteTextures(1, &strm->lumaTexture);
    strm->lumaTexture = 0;
  }
  if (strm->chromaUTexture) {
    glDeleteTextures(1, &strm->chromaUTexture);
    strm->chromaUTexture = 0;
  }
  if (strm->chromaVTexture) {
    glDeleteTextures(1, &strm->chromaVTexture);
    strm->chromaVTexture = 0;
  }
}

static void allocate_gl_textures(struct ios_stream *strm,
                                 int frameWidth, int frameHeight)
{
  TRACE_((THIS_FILE, "allocate_gl_textures %dx%d", frameWidth, frameHeight));
  // Y planes (init)
  glActiveTexture(GL_TEXTURE0);
  glBindTexture(GL_TEXTURE_2D, strm->lumaTexture);
  
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
  //glEnable(GL_TEXTURE_2D);
  
  glTexImage2D(GL_TEXTURE_2D, 0, GL_LUMINANCE, frameWidth, frameHeight, 0,
               GL_LUMINANCE, GL_UNSIGNED_BYTE, 0);
  
  // U-planes (init)
  glActiveTexture(GL_TEXTURE1);
  glBindTexture(GL_TEXTURE_2D, strm->chromaUTexture);
  
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
  
  glTexImage2D(GL_TEXTURE_2D, 0, GL_LUMINANCE, frameWidth/2, frameHeight/2, 0,
               GL_LUMINANCE, GL_UNSIGNED_BYTE, 0);
  
  // V-plane (init)
  glActiveTexture(GL_TEXTURE2);
  glBindTexture(GL_TEXTURE_2D, strm->chromaVTexture);
  
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
  
  glTexImage2D(GL_TEXTURE_2D, 0, GL_LUMINANCE, frameWidth/2, frameHeight/2, 0,
               GL_LUMINANCE, GL_UNSIGNED_BYTE, 0);
}

static void update_gl_textures (struct ios_stream *strm)
{
  //const pj_uint8_t *buffer = (const pj_uint8_t *)strm->buf;
  const pj_uint8_t *buffer = (const pj_uint8_t *)strm->frame->buf;
  pj_uint32_t width  = strm->size.w;
  pj_uint32_t height = strm->size.h;
 
  //TRACE_((THIS_FILE, "update_gl_textures %dx%d (%d)", width, height, buffer));
  
  // Y planes (update)
  glActiveTexture(GL_TEXTURE0);
  glBindTexture(GL_TEXTURE_2D, strm->lumaTexture);
  glUniform1i(uniformLocations[UNIFORM_Y], 0);
  
  glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0,
                  width,            // source width
                  height,            // source height
                  GL_LUMINANCE, GL_UNSIGNED_BYTE,
                  buffer);
  
  // U-planes (update)
  buffer += width*height;
  width >>= 1;
  height >>=1;
  
  glActiveTexture(GL_TEXTURE1);
  glBindTexture(GL_TEXTURE_2D, strm->chromaUTexture);
  glUniform1i(uniformLocations[UNIFORM_U], 1);
  
  glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0,
                  width,            // source width
                  height,            // source height
                  GL_LUMINANCE, GL_UNSIGNED_BYTE,
                  buffer);
  
  // V-planes (update)
  buffer += width*height;
  glActiveTexture(GL_TEXTURE2);
  glBindTexture(GL_TEXTURE_2D, strm->chromaVTexture);
  glUniform1i(uniformLocations[UNIFORM_V], 2);
  
  glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0,
                  width,            // source width
                  height,            // source height
                  GL_LUMINANCE, GL_UNSIGNED_BYTE,
                  buffer);
  
}

static CGRect textureSamplingRectForCroppingTextureWithAspectRatioToAspectRatio(CGSize textureAspectRatio, CGSize croppingAspectRatio)
{
  /*TRACE_((THIS_FILE, "textureSamplingRectForCroppingTextureWithAspectRatioToAspectRatio %f x %f ->%f x %f",
          textureAspectRatio.width, textureAspectRatio.height,
          croppingAspectRatio.width, croppingAspectRatio.height));*/
  
	CGRect normalizedSamplingRect = CGRectZero;
	CGSize cropScaleAmount = CGSizeMake(croppingAspectRatio.width / textureAspectRatio.width, croppingAspectRatio.height / textureAspectRatio.height);
	CGFloat maxScale = fmax(cropScaleAmount.width, cropScaleAmount.height);
	CGSize scaledTextureSize = CGSizeMake(textureAspectRatio.width * maxScale, textureAspectRatio.height * maxScale);
	
	if ( cropScaleAmount.height > cropScaleAmount.width ) {
		normalizedSamplingRect.size.width = croppingAspectRatio.width / scaledTextureSize.width;
		normalizedSamplingRect.size.height = 1.0;
	}
	else {
		normalizedSamplingRect.size.height = croppingAspectRatio.height / scaledTextureSize.height;
		normalizedSamplingRect.size.width = 1.0;
	}
	// Center crop
	normalizedSamplingRect.origin.x = (1.0 - normalizedSamplingRect.size.width)/2.0;
	normalizedSamplingRect.origin.y = (1.0 - normalizedSamplingRect.size.height)/2.0;
	
  /*TRACE_((THIS_FILE, "AspectRatio (%f, %f) %fx%f",
          normalizedSamplingRect.origin.x, normalizedSamplingRect.origin.y,
          normalizedSamplingRect.size.width, normalizedSamplingRect.size.height));*/
  
	return normalizedSamplingRect;
}

static void draw_gl_textures(struct ios_stream *strm)
{
  /*TRACE_((THIS_FILE, "draw_gl_textures %dx%d %dx%d %fx%f",
          strm->renderBufferWidth, strm->renderBufferHeight,
          strm->size.w, strm->size.h,
          strm->glView.bounds.size.width,  strm->glView.bounds.size.height));*/
  
  // Opengl doesn't work in background
	if ([UIApplication sharedApplication].applicationState != UIApplicationStateActive)
		return;
  
  // FIXME not optimal
  if (!strm->lumaTexture && !strm->chromaUTexture && !strm->chromaVTexture) {
    initialize_gl_textures(strm);
    allocate_gl_textures(strm, strm->size.w, strm->size.h);
  }
  
  update_gl_textures(strm);
  
  glBindFramebuffer(GL_FRAMEBUFFER, strm->frameBufferHandle);
  
  // Set the view port to the entire view
  glViewport(0, 0, strm->renderBufferWidth, strm->renderBufferHeight);
	
  static const GLfloat squareVertices[] = {
    -1.0f, -1.0f,
    1.0f, -1.0f,
    -1.0f,  1.0f,
    1.0f,  1.0f,
  };
  
	// The texture vertices are set up such that we flip the texture vertically.
	// This is so that our top left origin buffers match OpenGL's bottom left texture coordinate system.
#if 1
	/*CGRect textureSamplingRect =  textureSamplingRectForCroppingTextureWithAspectRatioToAspectRatio(&CGSizeMake(frameWidth, frameHeight), self.bounds.size);*/
  	CGRect textureSamplingRect =  textureSamplingRectForCroppingTextureWithAspectRatioToAspectRatio(
           CGSizeMake(strm->size.w, strm->size.h), CGSizeMake(strm->renderBufferWidth, strm->renderBufferHeight));
#else
  CGRect textureSamplingRect = CGRectMake(0.0, 0.0, 1.0, 1.0);
#endif
	GLfloat textureVertices[] = {
		CGRectGetMinX(textureSamplingRect), CGRectGetMaxY(textureSamplingRect),
		CGRectGetMaxX(textureSamplingRect), CGRectGetMaxY(textureSamplingRect),
		CGRectGetMinX(textureSamplingRect), CGRectGetMinY(textureSamplingRect),
		CGRectGetMaxX(textureSamplingRect), CGRectGetMinY(textureSamplingRect),
	};
	
  // Draw the texture on the screen with OpenGL ES 2
  //[self renderWithSquareVertices:squareVertices textureVertices:textureVertices];
  // Update attribute values.
	glVertexAttribPointer(ATTRIB_VERTEX, 2, GL_FLOAT, 0, 0, squareVertices);
	glEnableVertexAttribArray(ATTRIB_VERTEX);
	glVertexAttribPointer(ATTRIB_TEXTUREPOSITON, 2, GL_FLOAT, 0, 0, textureVertices);
	glEnableVertexAttribArray(ATTRIB_TEXTUREPOSITON);
  
  // Update uniform values if there are any
  
  // Validate program before drawing. This is a good check, but only really necessary in a debug build.
  // DEBUG macro must be defined in your debug configurations if that's not already the case.
#if defined(DEBUG)
  if (glueValidateProgram(strm->glProgram) != 0) {
    PJ_LOG(1, (THIS_FILE, "Failed to validate program: %d", strm->glProgram));
    return;
  }
#endif
	
	glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
  
  // Present
  glBindRenderbuffer(GL_RENDERBUFFER, strm->colorBufferHandle);
  [strm->glContext presentRenderbuffer:GL_RENDERBUFFER];
  
  //[self cleanUpTextures];
}


static pj_status_t init_ios_ren(struct ios_stream *strm)
{
    const pjmedia_video_format_detail *vfd;
    ios_fmt_info *qfi = get_ios_format_info(strm->param.fmt.id);

    if (!qfi) {
        return PJMEDIA_EVID_BADFORMAT;
    }

    vfd = pjmedia_format_get_video_format_detail(&strm->param.fmt, PJ_TRUE);
    pj_memcpy(&strm->size, &vfd->size, sizeof(vfd->size));


    /* Get the main window */
	UIWindow *window = [[UIApplication sharedApplication] keyWindow];

	if (strm->param.flags & PJMEDIA_VID_DEV_CAP_OUTPUT_WINDOW &&
      strm->param.window.info.ios.window)
    window = (UIWindow *)strm->param.window.info.ios.window;

  /* Init view */
    /*strm->glView = [[GLKView alloc] initWithFrame:[window bounds]
                                          context:strm->glContext];*/
  strm->glView = [[GLView alloc] initWithFrame:[window bounds]];
  if (!strm->glView) {
    return PJ_ENOMEM;
  }
  [strm->glView setOpaque:YES];
  
  // Initialize OpenGL layer
  CAEAGLLayer* eaglLayer = (CAEAGLLayer *)[strm->glView layer];
  [eaglLayer setOpaque:YES];
  [eaglLayer setDrawableProperties:[NSDictionary dictionaryWithObjectsAndKeys:
                                    [NSNumber numberWithBool:NO],
                                    kEAGLDrawablePropertyRetainedBacking,
                                    kEAGLColorFormatRGBA8,
                                    kEAGLDrawablePropertyColorFormat,
                                    nil]];
  
  // Initialize OpenGL ES 2 Context
  strm->glContext = [[EAGLContext alloc] initWithAPI:kEAGLRenderingAPIOpenGLES2];
  if (!strm->glContext) {
    //strm->gl_context = [[EAGLContext alloc] initWithAPI:kEAGLRenderingAPIOpenGLES1];
    PJ_LOG(1, (THIS_FILE,"Failed to create ES context"));
    return PJMEDIA_EVID_SYSERR;
  }
  
  if (![EAGLContext setCurrentContext:strm->glContext]) {
    PJ_LOG(1, (THIS_FILE,"Problem with OpenGL context."));
    return PJMEDIA_EVID_SYSERR;
  }
  
  initialize_gl_buffers(strm);

    /* Apply the remaining settings */
    if (strm->param.flags & PJMEDIA_VID_DEV_CAP_OUTPUT_POSITION) {
        ios_stream_set_cap(&strm->base,
                           PJMEDIA_VID_DEV_CAP_OUTPUT_POSITION,
                           &strm->param.window_pos);
    }
    if (strm->param.flags & PJMEDIA_VID_DEV_CAP_OUTPUT_HIDE) {
        ios_stream_set_cap(&strm->base,
                           PJMEDIA_VID_DEV_CAP_OUTPUT_HIDE,
                           &strm->param.window_hide);
    }

	return PJ_SUCCESS;
}
                     
/* API: create stream */
static pj_status_t ios_factory_create_stream(
					pjmedia_vid_dev_factory *f,
					pjmedia_vid_dev_param *param,
					const pjmedia_vid_dev_cb *cb,
					void *user_data,
					pjmedia_vid_dev_stream **p_vid_strm)
{
    struct ios_factory *qf = (struct ios_factory*)f;
    pj_pool_t *pool;
    struct ios_stream *strm;
    const pjmedia_video_format_info *vfi;
    pj_status_t status = PJ_SUCCESS;

    PJ_ASSERT_RETURN(f && param && p_vid_strm, PJ_EINVAL);
    PJ_ASSERT_RETURN(param->fmt.type == PJMEDIA_TYPE_VIDEO &&
		     param->fmt.detail_type == PJMEDIA_FORMAT_DETAIL_VIDEO &&
                     (param->dir == PJMEDIA_DIR_CAPTURE ||
                     param->dir == PJMEDIA_DIR_RENDER),
		     PJ_EINVAL);
    TRACE_((THIS_FILE, "ios_factory_create_stream"));
    vfi = pjmedia_get_video_format_info(NULL, param->fmt.id);
    if (!vfi)
        return PJMEDIA_EVID_BADFORMAT;

    /* Create and Initialize stream descriptor */
    pool = pj_pool_create(qf->pf, "ios-dev", 4000, 4000, NULL);
    PJ_ASSERT_RETURN(pool != NULL, PJ_ENOMEM);

    strm = PJ_POOL_ZALLOC_T(pool, struct ios_stream);
    pj_memcpy(&strm->param, param, sizeof(*param));
    strm->pool = pool;
    strm->qf = qf;
    pj_memcpy(&strm->vid_cb, cb, sizeof(*cb));
    strm->user_data = user_data;


    /* Create capture stream here */
    if (param->dir & PJMEDIA_DIR_RENDER) {
        /* Create renderer stream here */
        /* Get the main window */
      //NSLog(@"ios_factory_create_stream %dx%d",
      //      strm->param.fmt.det.vid.size.w, strm->param.fmt.det.vid.size.h);
      int w = strm->param.fmt.det.vid.size.w;
      strm->param.fmt.det.vid.size.w = strm->param.fmt.det.vid.size.h;
      strm->param.fmt.det.vid.size.h = w;
        strm->bpp = vfi->bpp;
        run_func_on_main_thread(strm, init_ios_ren, &status);
        if (status != PJ_SUCCESS)
            goto on_error;
      pj_memcpy(param, &strm->param, sizeof(*param));
    }

    /* Apply the remaining settings */
    /*    
     if (param->flags & PJMEDIA_VID_DEV_CAP_INPUT_SCALE) {
	ios_stream_set_cap(&strm->base,
			  PJMEDIA_VID_DEV_CAP_INPUT_SCALE,
			  &param->fmt);
     }
     */
    /* Done */
    strm->base.op = &stream_op;
    *p_vid_strm = &strm->base;
    
    return PJ_SUCCESS;
    
on_error:
    ios_stream_destroy((pjmedia_vid_dev_stream *)strm);
    
    return status;
}

/* API: Get stream info. */
static pj_status_t ios_stream_get_param(pjmedia_vid_dev_stream *s,
				        pjmedia_vid_dev_param *pi)
{
    struct ios_stream *strm = (struct ios_stream*)s;

    PJ_ASSERT_RETURN(strm && pi, PJ_EINVAL);

    pj_memcpy(pi, &strm->param, sizeof(*pi));

/*    if (ios_stream_get_cap(s, PJMEDIA_VID_DEV_CAP_INPUT_SCALE,
                            &pi->fmt.info_size) == PJ_SUCCESS)
    {
        pi->flags |= PJMEDIA_VID_DEV_CAP_INPUT_SCALE;
    }
*/

    if (ios_stream_get_cap(s, PJMEDIA_VID_DEV_CAP_OUTPUT_WINDOW,
                           &pi->window) == PJ_SUCCESS)
    {
        pi->flags |= PJMEDIA_VID_DEV_CAP_OUTPUT_WINDOW;
    }
    if (ios_stream_get_cap(s, PJMEDIA_VID_DEV_CAP_OUTPUT_POSITION,
                           &pi->window_pos) == PJ_SUCCESS)
    {
        pi->flags |= PJMEDIA_VID_DEV_CAP_OUTPUT_POSITION;
    }
    if (ios_stream_get_cap(s, PJMEDIA_VID_DEV_CAP_OUTPUT_RESIZE,
                           &pi->disp_size) == PJ_SUCCESS)
    {
        pi->flags |= PJMEDIA_VID_DEV_CAP_OUTPUT_RESIZE;
    }
    if (ios_stream_get_cap(s, PJMEDIA_VID_DEV_CAP_OUTPUT_HIDE,
                           &pi->window_hide) == PJ_SUCCESS)
    {
        pi->flags |= PJMEDIA_VID_DEV_CAP_OUTPUT_HIDE;
    }
    if (ios_stream_get_cap(s, PJMEDIA_VID_DEV_CAP_OUTPUT_WINDOW_FLAGS,
                           &pi->window_flags) == PJ_SUCCESS)
    {
        pi->flags |= PJMEDIA_VID_DEV_CAP_OUTPUT_WINDOW_FLAGS;
    }
#if ORIENTATION
    if (ios_stream_get_cap(s, PJMEDIA_VID_DEV_CAP_ORIENTATION,
                         &pi->window_hide) == PJ_SUCCESS)
    {
      pi->flags |= PJMEDIA_VID_DEV_CAP_ORIENTATION;
    }
#endif /* ORIENTATION */

    return PJ_SUCCESS;
}

/* API: get capability */
static pj_status_t ios_stream_get_cap(pjmedia_vid_dev_stream *s,
				      pjmedia_vid_dev_cap cap,
				      void *pval)
{
    struct ios_stream *strm = (struct ios_stream*)s;

    PJ_UNUSED_ARG(strm);

    PJ_ASSERT_RETURN(s && pval, PJ_EINVAL);

    if (cap==PJMEDIA_VID_DEV_CAP_INPUT_SCALE)
    {
        return PJMEDIA_EVID_INVCAP;
#if ORIENTATION
    } else if (cap == PJMEDIA_VID_DEV_CAP_ORIENTATION) {
      int i;
      AVCaptureVideoOrientation videoOrientation;
    	pjmedia_orient *orient = (pjmedia_orient *)pval;
      //*orient = PJMEDIA_ORIENT_UNKNOWN;
      *orient = PJMEDIA_ORIENT_ROTATE_90DEG;
      // TODO Manage renderer and capture
      // videoOrientation = AVCaptureConnection videoOrientation
      /*for (i = 0; i < PJ_ARRAY_SIZE(ios_orients); ++i)
        if (ios_orients[i].av_orientation == videoOrientation)
          *orient = ios_orients[i].pjmedia_orient;*/
      return PJ_SUCCESS;
#endif /* ORIENTATION */
    } else if (cap == PJMEDIA_VID_DEV_CAP_OUTPUT_WINDOW) {
        pjmedia_vid_dev_hwnd *wnd = (pjmedia_vid_dev_hwnd *)pval;
      wnd->info.ios.window = nil;
        if (strm->glView)
        {
            wnd->info.ios.window = strm->glView;
            return PJ_SUCCESS;
        }
    //}  else if (cap==PJMEDIA_VID_DEV_CAP_OUTPUT_WINDOW_FLAGS) {
    }  else if (cap==PJMEDIA_VID_DEV_CAP_OUTPUT_RESIZE) {
        pjmedia_rect_size *size = (pjmedia_rect_size *)pval;

        if (strm->glView) {
          CGRect frame = [strm->glView frame];
          size->w = frame.size.width;
          size->h = frame.size.height;
          return PJ_SUCCESS;
        }
    } else if (cap==PJMEDIA_VID_DEV_CAP_OUTPUT_POSITION) {
        pjmedia_coord *pos = (pjmedia_coord *)pval;
        if (strm->glView) {
          CGRect frame = [strm->glView frame];
          pos->x = frame.origin.x;
          pos->y = frame.origin.y;
          return PJ_SUCCESS;
        }
    } else if (cap == PJMEDIA_VID_DEV_CAP_OUTPUT_HIDE) {
        if (strm->glView) {
          *((pj_bool_t *)pval) = ([strm->glView isHidden] ? PJ_TRUE : PJ_FALSE);
          return PJ_SUCCESS;
        }
    } //else {
	return PJMEDIA_EVID_INVCAP;
    //}
}

/* API: set capability */
static pj_status_t ios_stream_set_cap(pjmedia_vid_dev_stream *s,
				      pjmedia_vid_dev_cap cap,
				      const void *pval)
{
    struct ios_stream *strm = (struct ios_stream*)s;
  
  PJ_UNUSED_ARG(strm);

    PJ_ASSERT_RETURN(s && pval, PJ_EINVAL);

    if (cap==PJMEDIA_VID_DEV_CAP_INPUT_SCALE)
    {
      return PJ_SUCCESS;
    }
#if ORIENTATION
    else if (cap==PJMEDIA_VID_DEV_CAP_ORIENTATION)
    {
    	pjmedia_orient *orient = (pjmedia_orient *)pval;
      /*
       * AVCaptureConnection
       * @property(nonatomic) AVCaptureVideoOrientation videoOrientation
       *
       * enum {
       AVCaptureVideoOrientationPortrait           = 1,
       AVCaptureVideoOrientationPortraitUpsideDown = 2,
       AVCaptureVideoOrientationLandscapeRight     = 3,
       AVCaptureVideoOrientationLandscapeLeft      = 4,
       };
       typedef NSInteger AVCaptureVideoOrientation;
       */
    	return PJ_SUCCESS;
    }
#endif /* ORIENTATION */

    if (strm->glView)
    {
        if (cap==PJMEDIA_VID_DEV_CAP_OUTPUT_RESIZE)
        {
            pjmedia_rect_size *size = (pjmedia_rect_size *)pval;
          strm->renderBufferWidth = size->w;
          strm->renderBufferHeight = size->h;

            CGRect frame = [strm->glView frame];
            frame.size.width = size->w;
            frame.size.height = size->h;
            [strm->glView setFrame:frame];

            return PJ_SUCCESS;

        }
        else if (cap==PJMEDIA_VID_DEV_CAP_OUTPUT_POSITION)
        {
            pjmedia_coord *pos = (pjmedia_coord *)pval;

            CGRect frame = [strm->glView frame];
            frame.origin.x = pos->x;
            frame.origin.y = pos->y;
            [strm->glView setFrame:frame];
            return PJ_SUCCESS;
        }
        else if (cap==PJMEDIA_VID_DEV_CAP_OUTPUT_HIDE)
        {
            pj_bool_t hide = *(pj_bool_t *)pval;
            [strm->glView setHidden:(hide ? YES : NO)];
            return PJ_SUCCESS;
        }
        /*else if (cap == PJMEDIA_VID_DEV_CAP_OUTPUT_WINDOW)
        {
        	UIView *window = (UIView *)strm->param.window.info.ios.window;
        	[window addSubview:strm->imgView];
        }*/
    }
    return PJMEDIA_EVID_INVCAP;
}

/* API: Start stream. */
static pj_status_t ios_stream_start(pjmedia_vid_dev_stream *strm)
{
    struct ios_stream *stream = (struct ios_stream*)strm;

    PJ_LOG(4, (THIS_FILE, "Starting ios video stream"));

    stream->is_running = PJ_TRUE;

    return PJ_SUCCESS;
}

static pj_status_t put_frame(struct ios_stream *stream)
{
  const pjmedia_frame *frame = stream->frame;
  
  draw_gl_textures(stream);
  
  return PJ_SUCCESS;
}

/* API: Put frame from stream */
static pj_status_t ios_stream_put_frame(pjmedia_vid_dev_stream *strm,
                                        const pjmedia_frame *frame)
{
  struct ios_stream *stream = (struct ios_stream*)strm;
  pj_status_t status;
  
  //pj_assert(stream->frame_size >= frame->size);
  //pj_memcpy(stream->buf, frame->buf, frame->size);
  
  //stream->last_ts.u64 = frame->timestamp.u64;
  
  if (!stream->is_running)
    return PJ_EINVALIDOP;
  
  if (stream->frame_size < frame->size)
    return PJ_SUCCESS;
  
  
  stream->frame = frame;
  run_func_on_main_thread(stream, put_frame, &status);

  return status;
}

/* API: Stop stream. */
static pj_status_t ios_stream_stop(pjmedia_vid_dev_stream *strm)
{
    struct ios_stream *stream = (struct ios_stream*)strm;

    PJ_LOG(4, (THIS_FILE, "Stopping ios video stream"));
    
    stream->is_running = PJ_FALSE;
    
    return PJ_SUCCESS;
}

static pj_status_t destroy_ios(struct ios_stream *stream)
{
  [EAGLContext setCurrentContext:stream->glContext];
  
  uninitialize_gl_textures(stream);
  
  //[EAGLContext setCurrentContext:stream->glContext];

  if (stream->glProgram) {
    glDeleteProgram(stream->glProgram);
    stream->glProgram = 0;
  }
  
  uninitialize_gl_buffers(stream);

  if ([EAGLContext currentContext] == stream->glContext) {
    [EAGLContext setCurrentContext:nil];
    [stream->glContext release];
    stream->glContext = NULL;
  }

  if (stream->glView) {
    [stream->glView removeFromSuperview];
    [stream->glView release];
    stream->glView = nil;
  }

  return PJ_SUCCESS;
}

/* API: Destroy stream. */
static pj_status_t ios_stream_destroy(pjmedia_vid_dev_stream *strm)
{
    struct ios_stream *stream = (struct ios_stream*)strm;
    pj_pool_t *pool = stream->pool;
    pj_status_t status;

    PJ_ASSERT_RETURN(stream != NULL, PJ_EINVAL);
    TRACE_((THIS_FILE, "ios_stream_destroy"));
    ios_stream_stop(strm);

    run_func_on_main_thread(stream, destroy_ios, &status);
    if (status != PJ_SUCCESS)
    	return status;
    
    //pj_bzero(stream->buf, stream->frame_size);
    pj_bzero(stream, sizeof(*stream));
    pj_pool_release(pool);

    return PJ_SUCCESS;
}

#endif	/* PJMEDIA_VIDEO_DEV_HAS_IOS */
